import React from "react";
import Nav from "./components/Nav";
import Hero from "./components/Hero";
import Showcase from "./components/Showcase";
import Experience from "./components/Experience";
import Footer from "./components/Footer";
import FAQ from "./components/FAQ";
import Timer from "./components/Timer";

function App() {
  return (
    <div className="cursor-pointer font-opensans">
      <div className="mx-[15px] md:mx-[50px] lg:mx-[100px] my-10">
        <Nav />
        <Hero />
        <Timer />
        <Showcase />
        <Experience />
        <FAQ />
      </div>
      <Footer />
    </div>
  );
}

export default App;
