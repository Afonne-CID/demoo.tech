import React from 'react'
import frame1 from '../assets/features2.gif'
import frame2 from '../assets/features3.gif'
import frame3 from '../assets/features1.gif'

const Showcase = () => {
    const item = [
        {
            id: 1,
            name: 'Fashion Lovers',
            image: frame1,
            hoverHeader: "See How Your Favorites Look on You. Straight from Your Gallery!",
            hoverPara: "Upload any item from your photo library and try it on virtually in seconds. Experiment with different styles and looks before making a decision. Whether it's that new dress or trendy sunglasses, your perfect look is just a try-on away!"
        },
        {
            id: 2,
            name: 'Businesses',
            image: frame2,
            hoverHeader: "Put Your Products in the Spotlight with Virtual Try-Ons!",
            hoverPara: "Drive engagement, boost product visibility, and build trust by allowing shoppers to see how items look before they buy. Whether you're selling apparel, eyewear, or accessories, our platform brings your products to life in front of your customers!"
        },
        {
            id: 3,
            name: 'Web Search',
            image: frame3,
            hoverHeader: "Search and Try On Items from Anywhere on the Web.",
            hoverPara: "Found something you love online? Don’t just imagine it—try it on virtually! With our app, you can search for items from anywhere on the web and see how they look on you. Shopping online just got smarter and more fun—try before you buy from any corner of the web!"
        },
    ]
  return (
    <div className='flex justify-center pb-[120px]' id='features'>
        <div className='text-center'>
            <h1 className='text-[32px] md:text-[48px] font-bold mt-10 font-montserrat'>Try, Showcase, and Explore. The <br className='hidden md:block'/> Future of Shopping is Here!</h1>
            <p className='text-[14px] md:text-[16px] pt-5 pb-10'>Try on your favorite items, showcase your products, and explore anything from the <br className='hidden md:block'/>web—effortlessly and in real-time. The future of shopping starts here!</p>
            <div className='md:flex justify-center gap-10'>
                  {item.map((item)=>(
                     <div key={item.id} className='mb-5 group bg-purple-50 py-2 px-5 rounded-2xl transition-all  duration-700 ease-in-out hover:w-full md:hover:w-[629px]  hover:px-10 hover:bg-[#2B1EE4] hover:text-white '>
                         <h1 className='text-[24px] font-bold py-5 group-hover:hidden'>{item.name}</h1>
                        <img src={item.image} className='group-hover:hidden mx-auto'/>
                        <div className='hidden group-hover:block md:group-hover:flex items-center gap-3 text-left py-10'>
                            <div>
                            <h1 className='text-[24px] md:text-[30px] font-bold pb-5'>{item.hoverHeader}</h1>
                            <p className='text-[14px] md:text-[16px]'>{item.hoverPara}</p>
                            </div>
                            <img src={item.image} className='mx-auto mt-5 md:mt-0'/>
                        </div>
                     </div>
                   ))}
             </div>
        </div>
    </div>
  )
}

export default Showcase