import React from 'react'
import Button from './Button'
import vector from '../assets/experienceV.png'

const Experience = () => {
   
  return (
   
    <div className='relative bg-[#FFEDE2] w-full flex justify-center my-20 py-20 text-center rounded-2xl '>
      <div className='relative z-10 py-[50px] px-3'>
        <h1 className='text-[24px] md:text-[48px] text-[#1F2937] font-bold font-montserrat'>
          Be the First to Experience the <br className='hidden md:block'/> Future of Shopping
        </h1>
        <p className='text-[14px] md:text-[16px]'>
          Join our waitlist and get exclusive early access to virtual try-ons across all categories. <br className='hidden md:block' /> 
          Don't miss out on transforming the way you shop!
        </p>
        <Button buttonColor="bg-[#827AF0]" />
      </div>
      <img 
        src={vector} 
        alt='' 
        className='absolute inset-0 w-full h-full object-contain top-[150px] md:top-0 md:object-cover' 
      />
    </div>
  )
}

export default Experience