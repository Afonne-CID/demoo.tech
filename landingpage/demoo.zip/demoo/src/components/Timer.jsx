import React, { useState, useEffect } from "react";

const Timer = () => {
  const secondsInADay = 86400;
  const initialTime = 30 * secondsInADay;

  const [timeLeft, setTimeLeft] = useState(initialTime);

  useEffect(() => {
    const countdown = setInterval(() => {
      setTimeLeft((prevTime) => {
        if (prevTime > 0) {
          return prevTime - 1;
        } else {
          clearInterval(countdown); // Clear interval when countdown ends
          return 0; // Stop at zero instead of resetting to initial time
        }
      });
    }, 1000);

    return () => clearInterval(countdown);
  }, []);

  const formatTime = (time) => {
    const days = Math.floor(time / secondsInADay);
    const hours = Math.floor((time % secondsInADay) / 3600);
    const minutes = Math.floor((time % 3600) / 60);
    const seconds = time % 60;

    return { days, hours, minutes, seconds };
  };

  const { days, hours, minutes, seconds } = formatTime(timeLeft);

  return (
    <div className="mt-20 flex justify-center">
      <div>
        <h1 className="text-[32px] font-semibold font-montserrat">
          DEMOO Mobile App Coming Soon!!!
        </h1>
        <div className="block md:flex gap-10 my-10 justify-center">
          <div className="bg-[#F3F4F6] px-2 rounded-xl text-center">
            <h1 className="text-[40px] font-bold bg-gradient-to-r from-[#948EF4] via-[#584DEA] to-[#827AF0] text-transparent bg-clip-text">
              {days}
            </h1>
            <span className="text-[16px]">DAYS</span>
          </div>
          <div className="bg-[#F3F4F6] px-2 rounded-xl text-center">
            <h1 className="text-[40px] font-bold bg-gradient-to-r from-[#948EF4] via-[#584DEA] to-[#827AF0] text-transparent bg-clip-text">
              {hours}
            </h1>
            <span className="text-[16px]">HOURS</span>
          </div>
          <div className="bg-[#F3F4F6] px-2 rounded-xl text-center">
            <h1 className="text-[40px] font-bold bg-gradient-to-r from-[#948EF4] via-[#584DEA] to-[#827AF0] text-transparent bg-clip-text">
              {minutes}
            </h1>
            <span className="text-[16px]">MINUTES</span>
          </div>
          <div className="bg-[#F3F4F6] px-2 rounded-xl text-center">
            <h1 className="text-[40px] font-bold bg-gradient-to-r from-[#948EF4] via-[#584DEA] to-[#827AF0] text-transparent bg-clip-text">
              {seconds}
            </h1>
            <span className="text-[16px]">SECONDS</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Timer;
