import React from 'react'
import FAQitem from './FAQitem';
import faqM from '../assets/faqM.png'

const FAQ = () => {
    const faqData = [
        {
          question: 'What can I try on using DEMOO?',
          answer:
            'You can try on a wide variety of items, including clothes, accessories, home decor, and more. Whether its something from your gallery, a product listed by businesses, or items from the web, the possibilities are endless!',
        },
        {
          question: 'Can I buy items directly through DEMOO?',
          answer:
            'No, our app is designed for virtual try-ons only. Once you try on an item, you’ll be directed to the brand’s website or affiliate link to complete your purchase.',
        },
        {
          question: 'How do businesses upload their products for virtual try-ons?',
          answer:
            'Businesses can easily upload products through their account dashboard. Once uploaded, customers can try on items virtually and engage with your brand before buying through your provided link.',
        },
        {
          question: 'Is the app only for fashion items?',
          answer:
            'No, our app is not limited to fashion. Users can try on a range of items, from apparel and accessories to furniture, eyewear, and  more!',
        },
        
      ];
  return (
    <div className='md:flex gap-10 justify-between w-full py-[120px]' id="faq">
        <div className='w-full'>
            <h1 className='text-[32px] md:text-[48px] font-bold font-montserrat'>Frequently Asked Questions</h1>
            <p className='text-[14px] md:text-[16px] my-10'>Get answers to the most common questions about our virtual try-on app.</p>
            {faqData.map((faq, index)=>(
                <FAQitem key={index} question={faq.question} answer={faq.answer}/>
            ))}
        </div>
        <div className=''>
            <img src={faqM} alt='' className='w-[700px] pt-10' />
            
        </div>
    </div>
  )
}

export default FAQ