import React, { useState } from "react";

const Button = ({ buttonColor }) => {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    // email validation
    if (!email.includes("@")) {
      setError("Please enter a valid email address.");
      return;
    }
    try {
      const response = await fetch(
        "https://demoo.pythonanywhere.com/waitlist",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (response.ok) {
        setSubmitted(true);
        setError("");
      } else {
        setError("Something went wrong, please try again later.");
      }
    } catch (err) {
      setError("Failed to submit. Please try again.");
    }
  };
  return (
    <div id="waitlist">
      {!submitted ? (
        <form
          onSubmit={handleSubmit}
          className="block md:flex gap-3 mx-auto justify-center mt-10">
          <input
            type="email"
            placeholder="Enter email address"
            className="rounded-full py-[10px] md:py-[13px] px-[13px] md:px-[16px] text-[16px] w-[223px] bg-transparent border-2 border-[#9CA3AF] mb-3 md:mb-0"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <button
            type="submit"
            className={`text-[#F7F7FE] w-[147px] text-[16px] py-[13px] px-[16px] rounded-full ${buttonColor}`}>
            Join Waitlist
          </button>
        </form>
      ) : (
        <p className="text-green-500 text-lg font-medium">
          Thank you for joining the waitlist! 🎉
        </p>
      )}
      {error && <p className="text-red-500">{error}</p>}
    </div>
  );
};

export default Button;
