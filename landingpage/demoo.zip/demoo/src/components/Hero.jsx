import React from "react";
import heroV from "../assets/heroV.svg";
import frame1 from "../assets/herogif.gif";
import Button from "./Button";
import pol from "../assets/vector-2.png";
import vol from "../assets/mop.svg";
import bob from "../assets/bob.svg";
import lop from "../assets/lop.svg";

const Hero = () => {
  return (
    <div className="relative pb9 mt-10 rounded-[20px] bg-[#FFEDE2] w-full  pt-[120px] text-center overflow-hidden">
      <h1 className="tracking-wide text-[30px] md:text-[60px] lg:text-[72px] font-bold px-3 font-montserrat">
        Discover Your Perfect <br className="hidden md:block" /> Look with{" "}
        <span className="bg-gradient-to-r from-[#3F33E7] to-[#F35B25] bg-clip-text text-transparent">
          DEMOO
        </span>
      </h1>
      <h2 className="text-[14px] md:text-lg text-[#374151] my-5 px-2 font-opensans">
        Say goodbye to guesswork and hello to style confidence. Try on clothes,{" "}
        <br className="hidden md:block" /> hairstyles, and accessories virtually
        before making a purchase.
      </h2>
      <Button buttonColor="bg-[#111827]" />

      <div className="w-[100%] relative lef5-[50%] overflow-hidden ">
        <div className="relative scale-100 min-[288px]:scale-110 min-[1622px]:scale-100 min-[1622px]:left-[10%]">
          <img src={bob} />
        </div>
      </div>
    </div>
  );
};

export default Hero;
