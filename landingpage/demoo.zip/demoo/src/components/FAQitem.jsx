import React, {useState} from 'react'
import faq from '../assets/faq.svg'


const FAQitem = ({ question, answer }) => {
    const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="border-b border-gray-300 py-4">
      <div
        className="flex justify-between items-center cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        <h3 className="text-lg md:text-[24px] font-semibold text-gray-800">{question}</h3>
        <img
          src={faq}
          alt="Toggle FAQ"
          className={`w-[50px] h-8 transition-transform duration-500 ${
            isOpen ? 'rotate-180' : 'rotate-0'
          }`}
        />
      </div>

    {/* Answer */}
    <div
      className={`mt-2 w-[80%] md:w-[720px] text-gray-700 transition-max-height duration-500 ease-in-out overflow-hidden ${
        isOpen ? 'max-h-[500px]' : 'max-h-0'
      }`}
    >
      <p className='text-[14px] md:text-[16px]'>{answer}</p>
    </div>
  </div>
  )
}

export default FAQitem