import React, { useState } from "react";
import logo from "../assets/logo.png";
import { FiMenu, FiX } from "react-icons/fi";

function Nav() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const li = [
    {
      id: 1,
      name: "Features",
      ident: "#features",
    },
    {
      id: 2,
      name: "Waitlist",
      ident: "#waitlist",
    },
    {
      id: 3,
      name: "FAQ's",
      ident: "#faq",
    },
    {
      id: 4,
      name: "Contact",
      ident: "#contact",
    },
  ];

  return (
    <div className="relative z-10 flex justify-between items-center p-4">
      <img src={logo} alt="logo" className="h-10" />
      <ul className="hidden md:flex gap-5">
        {li.map((item) => (
          <a key={item.id} href={item.ident}>
            <li className="text-[16px] font-semibold hover:text-[#2B1EE4]">
              {item.name}
            </li>
          </a>
        ))}
      </ul>

      <button className="hidden md:block w-[147px] bg-[#827AF0] hover:bg-gradient-to-r from-[#3F33E7] to-[#F35B25] px-[16px] py-[13px] rounded-full text-[16px] text-[#F9FAFB] font-semibold">
        Join waitlist
      </button>

      {/* Mobile Hamburger Menu Icon */}
      <div className="md:hidden">
        <button onClick={toggleMenu} className="text-3xl">
          {isOpen ? (
            <FiX className="text-black" />
          ) : (
            <FiMenu className="text-black" />
          )}
        </button>
      </div>

      {/* Mobile Menu (visible on small screens) */}
      <div
        className={`${
          isOpen ? "block" : "hidden"
        } absolute top-0 left-0 w-full h-[600px] bg-white rounded-3xl shadow-2xl text-black font-semibold z-50 flex flex-col items-center justify-center space-y-8 md:hidden`}>
        {/* Mobile Close Button */}
        <button
          onClick={toggleMenu}
          className="absolute top-4 right-4 text-white text-3xl">
          <FiX color="red" />
        </button>

        <img src={logo} alt="logo" className="h-10" />
        {li.map((item) => (
          <a key={item.id} href={item.ident} onClick={toggleMenu}>
            <li className="text-[16px] font-semibold list-none hover:text-[#2B1EE4]">
              {item.name}
            </li>
          </a>
        ))}

        <button
          onClick={toggleMenu}
          className="w-[147px] bg-[#827AF0] hover:bg-gradient-to-r from-[#3F33E7] to-[#F35B25] px-[16px] py-[13px] rounded-full text-[16px] text-[#F9FAFB] font-semibold">
          Join waitlist
        </button>
      </div>
    </div>
  );
}

export default Nav;
