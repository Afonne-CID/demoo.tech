import React from 'react'
import logo from '../assets/logo2.png'
import linkedin from '../assets/Linkedin.svg'
import facebook from '../assets/Facebook.svg'
import instagram from '../assets/icon.svg'

const Footer = () => {
  return (
    <div className='bg-[#F3F4F6] w-full py-20 flex justify-center ' id='contact'>
        <div className='text-center'>
         <img src={logo} alt='logo' className='mx-auto mb-5'/>
          <p className='text-[20px]'>Follow us on social media and subscribe to our newsletter for the latest <br className='hidden md:block'/> news, exclusive offers, and sneak peeks into the app&apos;s features.</p>
          <div className='flex justify-center gap-10 mt-10'>
             <img src={linkedin} alt='' /> 
            <img src={instagram} alt='' />
            <img src={facebook} alt='' />
          </div>
          <p className='mt-20 text-[16px]'>&copy; 2024 DEMOO| All Rights Reserved</p>
       </div>
      
    </div>
  )
}

export default Footer